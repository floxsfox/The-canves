extends Control

signal act_pressed

var move := Vector2.ZERO
var look := Vector2.ZERO
var act_down := false
var act_label := ""
var alt_text := ""
var integrity := 100.0
var sub_text := ""
var sub_t := 0.0
var task_text := ""
var task_frac := -1.0
var title_text := ""
var title_t := 0.0
var fade := 0.0
var joy_id := -1
var look_id := -1
var act_id := -1
var joy_c := Vector2.ZERO
var joy_p := Vector2.ZERO


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func take_look() -> Vector2:
    var l := look
    look = Vector2.ZERO
    return l


func _act_c() -> Vector2:
    return Vector2(size.x - 150.0, size.y - 150.0)


func _joy(p: Vector2) -> void:
    var dv := p - joy_c
    if dv.length() > 90.0:
        dv = dv.normalized() * 90.0
    joy_p = joy_c + dv
    move = dv / 90.0


func _input(e: InputEvent) -> void:
    if e is InputEventScreenTouch:
        var te: InputEventScreenTouch = e
        if te.pressed:
            if act_label != "" and te.position.distance_to(_act_c()) < 110.0:
                act_id = te.index
                act_down = true
                act_pressed.emit()
            elif te.position.x < size.x * 0.42 and joy_id == -1:
                joy_id = te.index
                joy_c = te.position
                _joy(te.position)
            elif look_id == -1:
                look_id = te.index
        else:
            if te.index == joy_id:
                joy_id = -1
                move = Vector2.ZERO
            elif te.index == look_id:
                look_id = -1
            elif te.index == act_id:
                act_id = -1
                act_down = false
    elif e is InputEventScreenDrag:
        var de: InputEventScreenDrag = e
        if de.index == joy_id:
            _joy(de.position)
        elif de.index == look_id:
            look += de.relative


func _process(d: float) -> void:
    sub_t = maxf(0.0, sub_t - d)
    title_t = maxf(0.0, title_t - d)
    queue_redraw()


func _draw() -> void:
    var f: Font = ThemeDB.fallback_font
    var w := size.x
    var h := size.y
    if fade > 0.0:
        draw_rect(Rect2(0.0, 0.0, w, h), Color(0, 0, 0, fade))
    # joystick melayang: muncul di tempat jempol menyentuh
    var c := Vector2(170.0, h - 170.0)
    var k := c
    if joy_id != -1:
        c = joy_c
        k = joy_p
    draw_circle(c, 90.0, Color(1, 1, 1, 0.07))
    draw_arc(c, 90.0, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 2.0)
    draw_circle(k, 38.0, Color(1, 1, 1, 0.3))
    # tombol aksi
    if act_label != "":
        var a := _act_c()
        var fa := 0.25
        if act_down:
            fa = 0.55
        draw_circle(a, 84.0, Color(0.3, 0.85, 1.0, fa))
        draw_arc(a, 84.0, 0.0, TAU, 48, Color(0.5, 0.95, 1.0, 0.9), 3.0)
        draw_string(f, a + Vector2(-84.0, 8.0), act_label, HORIZONTAL_ALIGNMENT_CENTER, 168.0, 22, Color.WHITE)
    # info atas
    draw_string(f, Vector2(30.0, 52.0), alt_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color(0.85, 1.0, 1.0))
    draw_string(f, Vector2(30.0, 82.0), "INTEGRITAS", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(1, 1, 1, 0.6))
    draw_rect(Rect2(30.0, 90.0, 240.0, 10.0), Color(1, 1, 1, 0.15))
    var ig := clampf(integrity / 100.0, 0.0, 1.0)
    draw_rect(Rect2(30.0, 90.0, 240.0 * ig, 10.0), Color(1.0 - ig, 0.4 + 0.6 * ig, 0.5, 1.0))
    if task_text != "":
        draw_string(f, Vector2(0.0, 150.0), task_text, HORIZONTAL_ALIGNMENT_CENTER, w, 24, Color(1.0, 0.85, 0.4))
    if task_frac >= 0.0:
        draw_rect(Rect2(w * 0.5 - 120.0, 170.0, 240.0, 12.0), Color(1, 1, 1, 0.2))
        draw_rect(Rect2(w * 0.5 - 120.0, 170.0, 240.0 * clampf(task_frac, 0.0, 1.0), 12.0), Color(1.0, 0.85, 0.3))
    if sub_t > 0.0:
        draw_string(f, Vector2(0.0, h - 60.0), sub_text, HORIZONTAL_ALIGNMENT_CENTER, w, 24, Color(1, 1, 1, clampf(sub_t, 0.0, 1.0)))
    if title_t > 0.0:
        var ta := clampf(minf(title_t, (5.0 - title_t) * 2.0), 0.0, 1.0)
        draw_string(f, Vector2(0.0, h * 0.4), title_text, HORIZONTAL_ALIGNMENT_CENTER, w, 44, Color(1, 1, 1, ta))

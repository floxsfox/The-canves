extends CharacterBody3D

var hud
var yaw := 0.0
var pitch := 0.0
var shake := 0.0
var roll := 0.0
var cam: Camera3D


func _ready() -> void:
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.4
    cap.height = 1.8
    cs.shape = cap
    cs.position.y = 0.9
    add_child(cs)
    cam = Camera3D.new()
    cam.position.y = 1.6
    cam.near = 0.12
    cam.far = 20000.0
    cam.fov = 72.0
    add_child(cam)
    cam.make_current()


func _process(_d: float) -> void:
    var l: Vector2 = hud.take_look()
    yaw -= l.x * 0.0045
    pitch = clampf(pitch - l.y * 0.0045, -1.45, 1.45)
    rotation.y = yaw
    cam.rotation.x = pitch
    cam.rotation.z = roll
    cam.h_offset = randf_range(-1.0, 1.0) * shake * 0.03
    cam.v_offset = randf_range(-1.0, 1.0) * shake * 0.03


func _physics_process(d: float) -> void:
    var m: Vector2 = hud.move
    var dir: Vector3 = global_transform.basis * Vector3(m.x, 0.0, m.y)
    velocity.x = dir.x * 4.2
    velocity.z = dir.z * 4.2
    if is_on_floor():
        velocity.y = 0.0
    else:
        velocity.y -= 14.0 * d
    move_and_slide()

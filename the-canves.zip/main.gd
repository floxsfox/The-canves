extends Node3D

const TARGET_ALT := 9000.0
const ALARMS := [1000.0, 2500.0, 4000.0, 5500.0, 7000.0, 8200.0]
const VALVE_NAMES := ["kiri depan", "kanan depan", "kiri belakang", "kanan belakang"]
const LINES := [
    [10.0, "Roket naik. Semuanya terasa normal."],
    [300.0, "Awan-awan ini... bentuknya sama persis."],
    [1200.0, "Matahari tidak bergeser sejak kita berangkat."],
    [2800.0, "Langit gelap. Tapi bintangnya terlalu rapi, seperti titik di kertas."],
    [4500.0, "Ada garis lurus tipis di langit. Sebuah sambungan."],
    [6200.0, "Garis itu bertambah. Langit ini punya sisi."],
    [7600.0, "Layar berkedip. Ada angka yang salah di panel."],
    [8700.0, "Kita bukan menuju luar angkasa. Kita menuju dinding."],
]

var hud
var player
var rv: Node3D
var env: Environment
var sky_mat: ShaderMaterial
var shard_mat: ShaderMaterial
var overlay_mat: ShaderMaterial
var cloud_mat: StandardMaterial3D
var sun: DirectionalLight3D
var lamp: OmniLight3D
var ground: MeshInstance3D
var giant: MeshInstance3D
var clouds: Array[Node3D] = []
var shards: Array[MeshInstance3D] = []
var valve_beams: Array[MeshInstance3D] = []
var audio_pb: AudioStreamGeneratorPlayback
var phase := 0
var alt := 0.0
var speed := 0.0
var inst := 0.0
var t := 0.0
var integrity := 100.0
var kick := 0.0
var tear_t := 0.0
var txt_t := 0.0
var mute_t := 0.0
var lp := 0.0
var line_i := 0
var alarm_i := 0
var ck_alt := 0.0
var ck_alarm := 0
var task_on := false
var task_t := 0.0
var task_hold := 0.0
var valve_i := 0
var ending_t := 0.0
var ending_shown := false


func _ready() -> void:
    randomize()
    _build_env()
    _build_rocket()
    _build_world()
    _build_ui()
    _build_audio()
    player = preload("res://player.gd").new()
    player.hud = hud
    add_child(player)
    player.position = Vector3(0.0, 0.1, 3.0)
    hud.act_pressed.connect(_on_act)
    hud.title_text = "LEVEL 1  -  SKYBOX"
    hud.title_t = 5.0


func _mat(c: Color, metal := 0.0, rough := 0.6) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.metallic = metal
    m.roughness = rough
    return m


func _box(size: Vector3, pos: Vector3, mat: Material, solid := true) -> void:
    var m := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    m.mesh = bm
    m.material_override = mat
    m.position = pos
    rv.add_child(m)
    if solid:
        var b := StaticBody3D.new()
        var cs := CollisionShape3D.new()
        var sh := BoxShape3D.new()
        sh.size = size
        cs.shape = sh
        b.position = pos
        b.add_child(cs)
        add_child(b)


func _valve_p(i: int) -> Vector3:
    var x := -4.0
    if i % 2 == 1:
        x = 4.0
    var z := -4.0
    if i >= 2:
        z = 4.0
    return Vector3(x, 0.0, z)


func _cloud_pos(y: float) -> Vector3:
    var a := randf() * TAU
    var r := randf_range(60.0, 220.0)
    return Vector3(cos(a) * r, y, sin(a) * r)


func _build_env() -> void:
    sky_mat = ShaderMaterial.new()
    sky_mat.shader = load("res://sky.gdshader")
    var sky := Sky.new()
    sky.sky_material = sky_mat
    sky.radiance_size = Sky.RADIANCE_SIZE_32
    env = Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.55, 0.6, 0.7)
    env.ambient_light_energy = 0.9
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_density = 0.0012
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50.0, 30.0, 0.0)
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 30.0
    add_child(sun)
    sky_mat.set_shader_parameter("sun_dir", sun.basis.z)
    lamp = OmniLight3D.new()
    lamp.position = Vector3(0.0, 3.0, 0.0)
    lamp.omni_range = 14.0
    lamp.light_color = Color(1.0, 0.92, 0.8)
    lamp.light_energy = 1.3
    add_child(lamp)


func _build_rocket() -> void:
    rv = Node3D.new()
    add_child(rv)
    var iron := _mat(Color(0.32, 0.34, 0.37), 0.7, 0.45)
    var dark := _mat(Color(0.1, 0.11, 0.13), 0.5, 0.5)
    var glass := _mat(Color(0.6, 0.85, 1.0, 0.16), 0.0, 0.05)
    glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    glass.cull_mode = BaseMaterial3D.CULL_DISABLED
    var scr := _mat(Color(0.1, 0.9, 1.0))
    scr.emission_enabled = true
    scr.emission = Color(0.1, 0.9, 1.0)
    scr.emission_energy_multiplier = 1.5
    # lantai besi
    _box(Vector3(10.0, 0.4, 10.0), Vector3(0.0, -0.2, 0.0), iron)
    for i in range(-4, 5, 2):
        _box(Vector3(10.0, 0.02, 0.12), Vector3(0.0, 0.01, float(i)), dark, false)
        _box(Vector3(0.12, 0.02, 10.0), Vector3(float(i), 0.01, 0.0), dark, false)
    # dinding kaca (solid) dan atap kaca
    _box(Vector3(10.0, 3.6, 0.1), Vector3(0.0, 1.8, -5.0), glass)
    _box(Vector3(10.0, 3.6, 0.1), Vector3(0.0, 1.8, 5.0), glass)
    _box(Vector3(0.1, 3.6, 10.0), Vector3(-5.0, 1.8, 0.0), glass)
    _box(Vector3(0.1, 3.6, 10.0), Vector3(5.0, 1.8, 0.0), glass)
    _box(Vector3(10.0, 0.1, 10.0), Vector3(0.0, 3.65, 0.0), glass, false)
    # rangka besi
    for s in [-5.0, 5.0]:
        _box(Vector3(10.3, 0.2, 0.3), Vector3(0.0, 3.7, s), iron, false)
        _box(Vector3(0.3, 0.2, 10.3), Vector3(s, 3.7, 0.0), iron, false)
        _box(Vector3(10.3, 0.12, 0.2), Vector3(0.0, 1.1, s), iron, false)
        _box(Vector3(0.2, 0.12, 10.3), Vector3(s, 1.1, 0.0), iron, false)
        for s2 in [-5.0, 5.0]:
            _box(Vector3(0.3, 3.8, 0.3), Vector3(s, 1.9, s2), iron, false)
    # konsol peluncur
    _box(Vector3(2.4, 1.0, 0.9), Vector3(0.0, 0.5, -4.2), dark)
    _box(Vector3(2.0, 0.04, 0.6), Vector3(0.0, 1.02, -4.2), scr, false)
    # katup tekanan di empat sudut
    var vm := _mat(Color(0.8, 0.35, 0.1), 0.6, 0.4)
    var bm := StandardMaterial3D.new()
    bm.albedo_color = Color(0.3, 0.95, 1.0, 0.35)
    bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    for i in 4:
        var p := _valve_p(i)
        var cm := CylinderMesh.new()
        cm.top_radius = 0.25
        cm.bottom_radius = 0.25
        cm.height = 0.7
        var body := MeshInstance3D.new()
        body.mesh = cm
        body.material_override = vm
        body.position = p + Vector3(0.0, 0.35, 0.0)
        rv.add_child(body)
        var bc := CylinderMesh.new()
        bc.top_radius = 0.1
        bc.bottom_radius = 0.1
        bc.height = 3.4
        var beam := MeshInstance3D.new()
        beam.mesh = bc
        beam.material_override = bm
        beam.position = p + Vector3(0.0, 1.7, 0.0)
        beam.visible = false
        rv.add_child(beam)
        valve_beams.append(beam)


func _build_world() -> void:
    ground = MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(20000.0, 20000.0)
    ground.mesh = pm
    ground.material_override = _mat(Color(0.22, 0.42, 0.22), 0.0, 1.0)
    add_child(ground)
    cloud_mat = _mat(Color(1, 1, 1, 0.92), 0.0, 1.0)
    cloud_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    cloud_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    var sm := SphereMesh.new()
    sm.radius = 1.0
    sm.height = 2.0
    sm.radial_segments = 12
    sm.rings = 6
    for i in 16:
        var c := Node3D.new()
        for k in 4:
            var m := MeshInstance3D.new()
            m.mesh = sm
            m.material_override = cloud_mat
            m.position = Vector3(float(k - 2) * 14.0, 0.0, float(k % 2) * 8.0)
            m.scale = Vector3(18.0, 6.0, 14.0)
            c.add_child(m)
        c.position = _cloud_pos(randf_range(-150.0, 250.0))
        add_child(c)
        clouds.append(c)
    shard_mat = ShaderMaterial.new()
    shard_mat.shader = load("res://glitch.gdshader")
    var xm := BoxMesh.new()
    for i in 14:
        var s := MeshInstance3D.new()
        s.mesh = xm
        s.material_override = shard_mat
        s.scale = Vector3(randf_range(3.0, 20.0), randf_range(3.0, 40.0), randf_range(1.0, 12.0))
        s.rotation = Vector3(randf() * TAU, randf() * TAU, randf() * TAU)
        s.position = _cloud_pos(randf_range(-200.0, 300.0))
        s.visible = false
        add_child(s)
        shards.append(s)
    giant = MeshInstance3D.new()
    var gs := SphereMesh.new()
    gs.radius = 2600.0
    gs.height = 5200.0
    gs.radial_segments = 48
    gs.rings = 24
    giant.mesh = gs
    var gm := _mat(Color(0.03, 0.035, 0.06), 0.0, 1.0)
    gm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    giant.material_override = gm
    giant.position = Vector3(3200.0, 2200.0, -9000.0)
    giant.visible = false
    add_child(giant)


func _build_ui() -> void:
    var cl := CanvasLayer.new()
    cl.layer = 1
    add_child(cl)
    var cr := ColorRect.new()
    cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
    overlay_mat = ShaderMaterial.new()
    overlay_mat.shader = load("res://overlay.gdshader")
    cr.material = overlay_mat
    cl.add_child(cr)
    cr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var hl := CanvasLayer.new()
    hl.layer = 2
    add_child(hl)
    hud = preload("res://hud.gd").new()
    hl.add_child(hud)


func _build_audio() -> void:
    var g := AudioStreamGenerator.new()
    g.mix_rate = 22050.0
    g.buffer_length = 0.25
    var ap := AudioStreamPlayer.new()
    ap.stream = g
    add_child(ap)
    ap.play()
    audio_pb = ap.get_stream_playback() as AudioStreamGeneratorPlayback


func _audio(vol: float, d: float) -> void:
    if audio_pb == null:
        return
    if mute_t > 0.0:
        mute_t -= d
    elif inst > 0.3 and randf() < 0.01 * inst:
        mute_t = 0.1
    var v := vol
    if mute_t > 0.0:
        v = 0.0
    var n: int = audio_pb.get_frames_available()
    for i in n:
        lp += (randf() * 2.0 - 1.0 - lp) * 0.035
        audio_pb.push_frame(Vector2(lp, lp) * v)


func _say(s: String, dur: float) -> void:
    hud.sub_text = s
    hud.sub_t = dur


func _corrupt(s: String) -> String:
    var o := ""
    for ch in s:
        if ch != " " and randf() < 0.4:
            o += "#@%?01X&$"[randi() % 9]
        else:
            o += ch
    return o


func _on_act() -> void:
    if phase == 0:
        var pp: Vector3 = player.position
        if Vector2(pp.x, pp.z).distance_to(Vector2(0.0, -4.2)) < 2.8:
            phase = 1
            speed = 0.0
            _say("Mesin menyala. Tahan posisi. Kita naik.", 5.0)
    elif phase == 2 and ending_t > 9.0:
        get_tree().reload_current_scene()


func _start_task() -> void:
    task_on = true
    task_t = 25.0
    task_hold = 0.0
    valve_i = randi() % 4
    valve_beams[valve_i].visible = true
    _say("Tekanan kritis! Katup " + VALVE_NAMES[valve_i] + " menyala.", 5.0)


func _end_task(ok: bool) -> void:
    task_on = false
    valve_beams[valve_i].visible = false
    alarm_i += 1
    if ok:
        integrity = minf(100.0, integrity + 15.0)
        ck_alt = alt
        ck_alarm = alarm_i
        _say("Tekanan stabil.", 3.0)
    else:
        integrity -= 35.0
        kick = 1.5
        if integrity <= 0.0:
            alt = ck_alt
            alarm_i = ck_alarm
            integrity = 100.0
            speed = 0.0
            _say("Roket terguncang. Sistem memulihkan ke titik terakhir.", 5.0)
        else:
            _say("Katup gagal ditahan. Badan roket retak.", 4.0)


func _process(d: float) -> void:
    t += d
    var pp: Vector3 = player.position
    var lab := ""
    if phase == 0:
        if Vector2(pp.x, pp.z).distance_to(Vector2(0.0, -4.2)) < 2.8:
            lab = "LUNCURKAN"
    elif phase == 1:
        speed = move_toward(speed, 24.0, 3.0 * d)
        alt = minf(alt + speed * d, TARGET_ALT)
        if line_i < LINES.size() and alt >= LINES[line_i][0]:
            _say(LINES[line_i][1], 6.5)
            line_i += 1
        if not task_on and alarm_i < ALARMS.size() and alt >= ALARMS[alarm_i]:
            _start_task()
        if task_on:
            task_t -= d
            var near: bool = pp.distance_to(_valve_p(valve_i)) < 1.8
            if near:
                lab = "TAHAN"
                if hud.act_down:
                    task_hold += d
                else:
                    task_hold = maxf(0.0, task_hold - d)
            else:
                task_hold = maxf(0.0, task_hold - d)
            if task_hold >= 2.0:
                _end_task(true)
            elif task_t <= 0.0:
                _end_task(false)
        if alt >= TARGET_ALT:
            phase = 2
            ending_t = 0.0
            if task_on:
                task_on = false
                valve_beams[valve_i].visible = false
    else:
        ending_t += d
        speed = move_toward(speed, 4.0, 2.0 * d)
        if ending_t > 2.5 and not ending_shown:
            ending_shown = true
            _say("Dinding langit retak. Di baliknya: BLACKBOX.", 9.0)
            hud.title_text = "LEVEL 1 SELESAI  -  LEVEL 2 MENYUSUL"
            hud.title_t = 6.0
        if ending_t > 9.0:
            lab = "ULANG"
    kick = move_toward(kick, 0.0, 0.7 * d)

    # faktor lingkungan
    var space := smoothstep(1500.0, 5000.0, alt)
    var seam := smoothstep(4500.0, 8500.0, alt)
    inst = smoothstep(3500.0, 9000.0, alt)
    if phase == 2:
        inst = 1.0
        seam = 1.0
    sky_mat.set_shader_parameter("space", space)
    sky_mat.set_shader_parameter("glitch", inst)
    sky_mat.set_shader_parameter("seam", seam)
    sky_mat.set_shader_parameter("t", t)
    shard_mat.set_shader_parameter("inst", inst)
    overlay_mat.set_shader_parameter("inst", inst)
    env.fog_density = lerpf(0.0012, 0.00001, space)
    env.fog_light_color = Color(0.78, 0.88, 1.0).lerp(Color(0.0, 0.0, 0.01), space)
    env.ambient_light_color = Color(0.55, 0.6, 0.7).lerp(Color(0.14, 0.15, 0.22), space)
    sun.light_energy = lerpf(1.2, 0.9, space)
    cloud_mat.albedo_color = Color(1, 1, 1, 0.92).lerp(Color(0.1, 0.1, 0.16, 0.0), smoothstep(2500.0, 5500.0, alt))
    var flick := 0.0
    if randf() < 0.04 * inst:
        flick = 0.7
    lamp.light_energy = 1.3 * (1.0 - flick)

    # gerak dunia (roket tetap di titik nol agar koordinat stabil)
    var vs := speed * 2.0 * d
    for c in clouds:
        c.position.y -= vs
        if c.position.y < -160.0:
            c.position = _cloud_pos(c.position.y + 420.0)
    var show_shards := alt > 3500.0
    for s in shards:
        s.visible = show_shards
        s.position.y -= vs * 0.6
        if s.position.y < -220.0:
            s.position = _cloud_pos(s.position.y + 560.0)
        s.rotate_y(d * 0.15)
    ground.position.y = -(alt + 40.0)
    ground.visible = alt < 6000.0
    giant.visible = alt > 2500.0
    giant.position.y = 2200.0 - alt * 0.05

    # guncangan dan glitch pada roket
    var sp := speed / 24.0
    rv.position = Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * 0.006 * (sp + kick * 3.0 + inst * 2.0)
    if inst > 0.4 and randf() < 0.02 * inst:
        tear_t = 0.08
    tear_t -= d
    if tear_t > 0.0:
        rv.scale = Vector3(1.0 + 0.08 * randf(), 1.0 - 0.05 * randf(), 1.0 + 0.1 * randf())
    else:
        rv.scale = Vector3.ONE
    player.shake = sp * 0.25 + inst * 0.3 + kick
    var rl := 0.0
    if randf() < 0.05 * inst:
        rl = (randf() - 0.5) * 0.08
    player.roll = rl

    # HUD
    txt_t -= d
    if txt_t <= 0.0:
        txt_t = 0.12
        var s := "%d m" % int(alt)
        if randf() < inst * 0.5:
            s = _corrupt(s)
        hud.alt_text = "ALT  " + s
    hud.integrity = integrity
    hud.act_label = lab
    var tt := ""
    if phase == 0:
        tt = "Menuju konsol di depan, lalu luncurkan roket"
    elif task_on:
        tt = "TEKANAN KRITIS - menuju katup %s (%d dtk)" % [VALVE_NAMES[valve_i], int(ceilf(task_t))]
    hud.task_text = tt
    var tf := -1.0
    if task_on:
        tf = task_hold / 2.0
    hud.task_frac = tf
    var fd := 0.0
    if phase == 2:
        fd = clampf(ending_t / 6.0, 0.0, 0.8)
    hud.fade = fd
    _audio(0.08 + 0.9 * sp, d)
